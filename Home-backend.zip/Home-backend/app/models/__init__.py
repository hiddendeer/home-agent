"""数据库模型模块。"""

from app.models.user import User

__all__ = ["User"]
